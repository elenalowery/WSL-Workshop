from __future__ import print_function
import sys

def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)

import sys

def determineEligibility(args):

  if args["customerStatus"] == "N" and args["purchaseAmount"] > 50:
      if args["customerSegment"] == "Family":
          promotion = "PW3033"
      else:
          promotion = "PW3034"
  elif args["customerStatus"] == "E" and args["purchaseAmount"] > 100:
      if args["customerSegment"] == "Electronics":
          promotion = "PW3045"
      else:
          promotion = "PW3059"
      promotion = "PW3035"
  else:
      promotion="PW7809"
  return promotion

def init():

  # Do nothing for now

  pass