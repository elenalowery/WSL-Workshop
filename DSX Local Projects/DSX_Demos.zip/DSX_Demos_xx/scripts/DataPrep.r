
###################################
## Prepare customer_original.csv ##
###################################

## Load data
df <- read.csv(paste(Sys.getenv("DSX_PROJECT_DIR"),"/datasets/customer_original.csv",sep=""))

## Remove NULL values from 'Usage' column
df <- df[!is.na(df$Usage), ]

## Convert `LongDistance` column to numeric and rename
df$ValidLongDistance <- as.numeric(df$LongDistance)

## Remove NULL values from `ValidLongDistance`
df <- df[!is.na(df$ValidLongDistance), ]

## Create new column, `Dropped` as the total of `DroppedPeak` + `DroppedOffPeak`
df$Dropped <- df$DroppedPeak + df$DroppedOffPeak

## Drop unnecessary columns
df <- df[, !names(df) %in% c("DroppedPeak", "DroppedOffPeak", "LongDistance")]

## Create new column `IncomeGroup` & bucket income into 5 groups
df$IncomeGroup <- ''

for(i in 1:nrow(df)){
  if(df$Est.Income[i] >= 96.33 & df$Est.Income[i] < 24077.064){
    df$IncomeGroup[i] <- "Income_Group_1"
  } else if(df$Est.Income[i] >= 24077.064 & df$Est.Income[i] < 48057.798){
    df$IncomeGroup[i] <- "Income_Group_2"
  } else if(df$Est.Income[i] >= 48057.798 & df$Est.Income[i] < 48057.798){
    df$IncomeGroup[i] <- "Income_Group_3"
  } else if(df$Est.Income[i] >= 48057.798 & df$Est.Income[i] < 72038.532){
    df$IncomeGroup[i] <- "Income_Group_4"
  } else if (df$Est.Income[i] >= 96019.266 & df$Est.Income[i] <= 120000.0){
    df$IncomeGroup[i] <- "Income_Group_5"
  }
} 

## Create new column `CallerType` with values 'Domestic' and 'Both'
df$CallerType <- ifelse(df$International == 0, "Domestic", "Both")

## Write to disk
write.csv(df, file = paste(Sys.getenv("DSX_PROJECT_DIR"),"/datasets/customer_clean_r.csv",sep=""), row.names = F)

